package gupao_edu.part1.designModel.abstractFactory;

public interface INotes {
	
	void getNotes();
	
}
