package gupao_edu.part1.designModel.abstractFactory;

public class AbstractFactoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICourseFactory factory = new JavaTypeFactory();
		ISource source = factory.resource();
		INotes note = factory.notes();
		IVideo video = factory.video();
		source.getSource();
		note.getNotes();
		video.getVideo();
		
	}

}
