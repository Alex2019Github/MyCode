package gupao_edu.part1.designModel.abstractFactory;

public class Video implements IVideo {

	@Override
	public void getVideo() {
		// TODO Auto-generated method stub
		System.out.println("��ȡJava��Ƶ��");
	}

}
