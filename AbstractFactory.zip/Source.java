package gupao_edu.part1.designModel.abstractFactory;

public class Source implements ISource{

	@Override
	public void getSource() {
		// TODO Auto-generated method stub
		System.out.println("��ȡJavaԴ�룡");
	}

}
