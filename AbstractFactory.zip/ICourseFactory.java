package gupao_edu.part1.designModel.abstractFactory;

public interface ICourseFactory {
	
	ISource resource();
	
	INotes notes();

	IVideo video();
	
}
