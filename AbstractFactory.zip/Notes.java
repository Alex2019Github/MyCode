package gupao_edu.part1.designModel.abstractFactory;

public class Notes implements INotes{

	@Override
	public void getNotes() {
		// TODO Auto-generated method stub
		System.out.println("��ȡJava�ʼǣ�");
	}

}
