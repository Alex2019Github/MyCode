package gupao_edu.part1.designModel.factoryMethod;

import gupao_edu.part1.designModel.simpleFactory.ICourse;

public interface ICourseFactory {
	
	ICourse create();
	
}
