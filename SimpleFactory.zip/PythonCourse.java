package gupao_edu.part1.designModel.simpleFactory;

public class PythonCourse implements ICourse{

	@Override
	public void study() {
		// TODO Auto-generated method stub
		System.out.println("��Ҫѧϰpython�γ̣�");
	}

}
