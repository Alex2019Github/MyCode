package gupao_edu.part1.designModel.simpleFactory;

public class PHPCourse implements ICourse{

	@Override
	public void study() {
		// TODO Auto-generated method stub
		System.out.println("��ҪѧϰPHP�γ̣�");
	}

}
