package gupao_edu.part1.designModel.simpleFactory;

public class JavaCourse implements ICourse{

	@Override
	public void study() {
		// TODO Auto-generated method stub
		System.out.println("��ҪѧϰJava�γ̣�");
	}

}
