package gupao_edu.part1.designModel.simpleFactory;

public interface ICourse {
	
	void study();
	
}
