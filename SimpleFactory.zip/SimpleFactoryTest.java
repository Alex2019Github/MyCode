package gupao_edu.part1.designModel.simpleFactory;

public class SimpleFactoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ʵ�ּ򵥹�����ģʽ
		CourseFactory cf = new CourseFactory();
		ICourse java = cf.factory(JavaCourse.class);
		ICourse python = cf.factory(PythonCourse.class);
		ICourse php = cf.factory(PHPCourse.class);
		java.study();
		python.study();
		php.study();
	}

}
